import assert from "node:assert/strict";
import { tally, assign, hungarian } from "../js/assign.js";

// 1) Óptimo en un caso pequeño: A solo puede ganar una categoría
{
  const parts = [{ id: "A" }, { id: "B" }];
  const cats = [{ id: "c1" }, { id: "c2" }];
  const counts = { c1: { A: 3 }, c2: { A: 5, B: 1 } };
  const r = assign({ parts, cats, counts, diplomasPerPerson: 1, seed: 7 });
  assert.equal(r.find((x) => x.cid === "c2").pid, "A");
  assert.equal(r.find((x) => x.cid === "c1").pid, "B");
}

// 2) Húngaro vs fuerza bruta en matrices aleatorias pequeñas
{
  const perms = (n) => n <= 1 ? [[0]] : perms(n - 1).flatMap((p) => Array.from({ length: n }, (_, i) => [...p.slice(0, i), n - 1, ...p.slice(i)]));
  for (let t = 0; t < 50; t++) {
    const n = 5, a = Array.from({ length: n }, () => Array.from({ length: n }, () => Math.floor(Math.random() * 20)));
    const ans = hungarian(a);
    const got = ans.reduce((s, j, i) => s + a[i][j], 0);
    const best = Math.min(...perms(n).map((p) => p.reduce((s, j, i) => s + a[i][j], 0)));
    assert.equal(got, best);
  }
}

// 3) Votación nueva: 12 personas, 24 categorías; cada votante nomina a cada otra persona en una categoría distinta
const parts = Array.from({ length: 12 }, (_, i) => ({ id: `p${i}`, name: `P${i}` }));
const cats = Array.from({ length: 24 }, (_, i) => ({ id: `c${i}` }));
function randomVotes(rnd) {
  return parts.map((v) => {
    const catPool = cats.map((c) => c.id).sort(() => rnd() - 0.5);
    const picks = parts.filter((p) => p.id !== v.id).map((p, k) => ({ pid: p.id, cid: catPool[k] }));
    return { id: v.id, picks };
  });
}
{
  const votes = randomVotes(Math.random);
  const { counts, voted, invalid } = tally({ parts, cats, votes });
  assert.equal(invalid, 0);
  for (const p of parts) assert.equal(voted[p.id], 11);
  // todos reciben exactamente 11 votos en total
  for (const p of parts) {
    const got = cats.reduce((s, c) => s + (counts[c.id][p.id] || 0), 0);
    assert.equal(got, 11, `p ${p.id}`);
  }
  for (let seed = 1; seed <= 25; seed++) {
    const r = assign({ parts, cats, counts, diplomasPerPerson: 2, seed });
    assert.equal(r.length, 24);
    const per = {};
    r.forEach((x) => { per[x.pid] = (per[x.pid] || 0) + 1; });
    for (const p of parts) assert.equal(per[p.id], 2, `p ${p.id} seed ${seed}`);
    assert.equal(new Set(r.map((x) => x.cid)).size, 24);
  }
}

// 4) Votos inválidos se ignoran: autovoto, persona repetida, categoría repetida, ids inexistentes
{
  const votes = [{
    id: "p0",
    picks: [
      { pid: "p0", cid: "c0" },   // a sí mismo
      { pid: "p1", cid: "c1" },   // válido
      { pid: "p1", cid: "c2" },   // persona repetida
      { pid: "p2", cid: "c1" },   // categoría repetida
      { pid: "zz", cid: "c3" },   // persona inexistente
      { pid: "p3", cid: "cx" },   // categoría inexistente
      { pid: "p4", cid: "c4" },   // válido
    ],
  }, { id: "intruso", picks: [{ pid: "p1", cid: "c1" }] }];
  const { counts, voted, invalid } = tally({ parts, cats, votes });
  assert.equal(voted.p0, 2);
  assert.equal(invalid, 5);
  assert.equal(counts.c1.p1, 1);
  assert.equal(counts.c4.p4, 1);
  assert.equal(voted.intruso, undefined);
}

// 5) Más categorías que cupos → error claro
assert.throws(() => assign({ parts: [{ id: "A" }], cats: [{ id: "x" }, { id: "y" }], counts: {}, diplomasPerPerson: 1 }), /cupos/);

console.log("OK: todas las pruebas pasaron");
