import {
  db, ensureAnon, proofFor, doc, collection, getDoc, setDoc, onSnapshot, serverTimestamp, writeBatch,
} from "./firebase.js";
import { h, toast, confetti, avatar, slug, ceremonyView } from "./ui.js";

const app = document.getElementById("app");
const ME_KEY = "premios.me";

const S = {
  user: null,
  me: JSON.parse(localStorage.getItem(ME_KEY) || "null"), // { pid, proof }
  state: null,
  parts: [],
  cats: [],
  cer: null,
  items: [],     // mis propuestas
  picks: [],     // mis votos [{pid, cid}]: a cada persona, la categoría en la que la nomino
  mineLoaded: false,
  celebrated: false,
  lastKey: "",
};

const st = () => ({
  phase: "setup", eventTitle: "", proposalsPerPerson: 5, diplomasPerPerson: 2, registrationOpen: true, ...(S.state || {}),
});
const myName = () => S.parts.find((p) => p.id === S.me?.pid)?.name || "";

// ---------- arranque ----------
async function boot() {
  try {
    S.user = await ensureAnon();
  } catch (e) {
    app.replaceChildren(h("div", { class: "card" }, h("h3", {}, "No se pudo conectar"),
      h("p", { class: "mut" }, `${e.code || e.message}. Revisa js/config.js y que el inicio de sesión Anónimo esté activado en Firebase.`)));
    return;
  }
  const err = (e) => toast(`Error de conexión: ${e.code || e.message}`, true);
  onSnapshot(doc(db, "config", "state"), (s) => { S.state = s.exists() ? s.data() : null; render(); }, err);
  onSnapshot(collection(db, "participants"), (s) => {
    S.parts = s.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => a.name.localeCompare(b.name, "es"));
    render();
  }, err);
  onSnapshot(collection(db, "categories"), (s) => {
    S.cats = s.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => a.order - b.order);
    render();
  }, err);
  // Solo existe cuando el admin publica los diplomas al final
  onSnapshot(doc(db, "config", "ceremony"), (s) => { S.cer = s.exists() ? s.data() : null; render(); }, err);
}

async function loadMine() {
  S.mineLoaded = true;
  const { pid } = S.me;
  try { const d = await getDoc(doc(db, "proposals", pid)); S.items = d.exists() ? d.data().items || [] : []; } catch { S.items = []; }
  try { const d = await getDoc(doc(db, "votes", pid)); S.picks = d.exists() ? d.data().picks || [] : []; } catch { S.picks = []; }
  S.lastKey = "";
  render();
}

function logout() {
  localStorage.removeItem(ME_KEY);
  S.me = null; S.mineLoaded = false; S.items = []; S.picks = []; S.lastKey = "";
  render();
}

function writeError(e) {
  if (e.code === "permission-denied") {
    toast("No se pudo guardar: esta fase ya cerró o tu clave fue reiniciada. Si fue reiniciada, vuelve a entrar.", true);
  } else toast(`Error: ${e.message}`, true);
}

// ---------- render ----------
function render() {
  const s = st();
  const key = `${S.me?.pid || ""}|${s.phase}`;
  // No re-dibujar los formularios mientras la persona escribe
  if (s.phase === "proposing" && S.me && key === S.lastKey && app.querySelector("#propForm")) return;
  if (!S.me && key === S.lastKey && app.querySelector("#login")) return;
  S.lastKey = key;
  if (s.phase === "done" && S.me && !S.celebrated) { S.celebrated = true; setTimeout(confetti, 300); }

  const needsMine = S.me && !S.mineLoaded;
  if (needsMine) loadMine();

  app.replaceChildren(header(s), needsMine ? h("p", { class: "mut" }, "Cargando…") : body(s));
}

function header(s) {
  return h("header", { class: "top" },
    h("h1", {}, `🎓 Premios ${s.eventTitle || ""}`.trim()),
    S.me ? h("div", { class: "who" }, avatar(myName() || "?"), h("button", { class: "ghost sm", onclick: logout }, "Salir")) : null);
}

function body(s) {
  if (!S.state) {
    return h("div", { class: "card" }, h("h3", {}, "Todavía no hay nada aquí"),
      h("p", { class: "mut" }, "El administrador aún no ha abierto el juego. Vuelve en un rato."));
  }
  if (!S.me) return loginView();
  switch (s.phase) {
    case "setup": return infoCard("🙌", `¡Estás dentro, ${myName()}!`, "Pronto se abre la fase de propuestas de categorías. Vuelve en un rato con tu nombre y tu clave.");
    case "proposing": return proposingView(s);
    case "consolidating": return infoCard("🧩", "Armando las categorías", "El comité está escogiendo las mejores propuestas. Pronto verás la lista oficial.");
    case "consolidated": return consolidatedView();
    case "voting": return votingView();
    case "results":
    case "ceremony":
      return infoCard("🎭", "¡Los resultados son sorpresa!", "Se están contando los votos. Muy pronto habrá una presentación y después podrás descargar tus diplomas aquí.");
    case "done": return ceremonyView({ cer: S.cer, cats: S.cats, parts: S.parts, state: S.state, meId: S.me.pid, done: true });
    default: return infoCard("🎭", "…", "");
  }
}

const infoCard = (emoji, title, text) =>
  h("div", { class: "stage" }, h("div", { class: "big" }, emoji), h("h2", {}, title), h("p", { class: "mut" }, text));

// ---------- entrar o registrarse (nombre + clave) ----------
function loginView() {
  const name = h("input", { type: "text", autocomplete: "off", maxlength: 40, placeholder: "Tu nombre (como te conocen en el grupo)" });
  const pass = h("input", { type: "password", autocomplete: "off", maxlength: 40, placeholder: "Tu clave (mínimo 4 caracteres)" });
  const msg = h("p", { class: "bad sm" });
  const btn = h("button", { class: "btn", type: "submit" }, "Entrar");

  const submit = async (e) => {
    e.preventDefault();
    msg.textContent = "";
    const display = name.value.trim().replace(/\s+/g, " ");
    const pid = slug(display);
    if (display.length < 2 || pid === "x") { msg.textContent = "Escribe tu nombre (mínimo 2 letras)."; return; }
    if (pass.value.length < 4) { msg.textContent = "La clave debe tener al menos 4 caracteres."; return; }
    btn.disabled = true;
    let claimed = false;
    try {
      const proof = await proofFor(pid, pass.value);
      claimed = (await getDoc(doc(db, "claimed", pid))).exists();
      let welcome = "";
      if (!claimed) {
        // Primera vez con este nombre: se registra con la clave que escribió
        const partExists = (await getDoc(doc(db, "participants", pid))).exists();
        if (!partExists && st().registrationOpen === false) {
          msg.textContent = "Las inscripciones ya están cerradas. Si te registraste antes, escribe tu nombre igual que la primera vez.";
          return;
        }
        const b = writeBatch(db);
        if (!partExists) b.set(doc(db, "participants", pid), { name: display, uid: S.user.uid, at: serverTimestamp() });
        b.set(doc(db, "secrets", pid), { hash: proof, uid: S.user.uid, at: serverTimestamp() });
        b.set(doc(db, "claimed", pid), { at: serverTimestamp() });
        await b.commit();
        welcome = `¡Registrado! Bienvenido, ${display}`;
      }
      await setDoc(doc(db, "logins", pid), { uid: S.user.uid, proof, at: serverTimestamp() });
      S.me = { pid, proof };
      localStorage.setItem(ME_KEY, JSON.stringify(S.me));
      S.mineLoaded = false; S.lastKey = "";
      if (welcome) toast(welcome);
      render();
    } catch (err) {
      msg.textContent = err.code === "permission-denied"
        ? (claimed
          ? "Clave incorrecta. Si es la primera vez que entras y ese nombre ya existe, agrega tu apellido."
          : "No se pudo registrar. Revisa tu nombre o avísale al administrador.")
        : `Error: ${err.message}`;
    } finally {
      btn.disabled = false;
    }
  };

  return h("form", { class: "card", id: "login", onsubmit: submit },
    h("h3", {}, "Entrar o registrarme"),
    h("p", { class: "mut sm" }, "Escribe tu nombre y una clave. Si es tu primera vez, quedas registrado con esa clave; para volver a entrar usa el mismo nombre y la misma clave."),
    name, pass, btn, msg);
}

// ---------- propuestas ----------
function proposingView(s) {
  const n = s.proposalsPerPerson;
  const inputs = [];
  const status = h("p", { class: "mut sm" });
  const count = () => new Set(inputs.map((i) => i.value.trim().toLowerCase()).filter(Boolean)).size;
  const refresh = () => {
    const c = count();
    status.textContent = c === n ? `${c}/${n} ✔ Listas: pulsa Guardar` : `${c}/${n} categorías escritas (deben ser ${n}, distintas)`;
  };
  const form = h("form", {
    id: "propForm",
    onsubmit: async (e) => {
      e.preventDefault();
      const items = [...new Set(inputs.map((i) => i.value.trim()).filter(Boolean))];
      if (items.length !== n) {
        toast(`Debes escribir exactamente ${n} categorías distintas (llevas ${items.length}).`, true);
        return;
      }
      try {
        await setDoc(doc(db, "proposals", S.me.pid), { uid: S.user.uid, proof: S.me.proof, items, at: serverTimestamp() });
        S.items = items;
        toast(`¡Listo! Tus ${n} categorías quedaron guardadas ✔`);
      } catch (err) { writeError(err); }
    },
  });
  for (let i = 0; i < n; i++) {
    const inp = h("input", {
      type: "text", maxlength: 80, value: S.items[i] || "",
      placeholder: i === 0 ? 'Ej: "Mejor excusa del año"' : `Categoría ${i + 1}`,
      oninput: refresh,
    });
    inputs.push(inp); form.append(inp);
  }
  form.append(status, h("button", { class: "btn", type: "submit" }, `Guardar mis ${n} categorías`));
  refresh();
  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, `Propón ${n} categorías`),
      h("p", { class: "lead" }, "Ideas graciosas para premiar a alguien del grupo: “El que siempre llega tarde”, “Más probable que…”. Entre todas armamos las mejores."),
      h("p", { class: "mut sm" }, `Son obligatorias las ${n}. Puedes volver a editarlas hasta que se cierre esta fase.`)),
    h("div", { class: "card" }, form));
}

// ---------- categorías consolidadas (solo lectura) ----------
function consolidatedView() {
  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, "📋 Categorías oficiales"),
      h("p", { class: "lead" }, `Estas son las ${S.cats.length} categorías escogidas entre todas las propuestas. Pronto se abre la votación.`),
      h("p", { class: "mut sm" }, "En la votación nominarás a cada persona del grupo en una categoría distinta, así que ve pensando quién va en cuál.")),
    h("div", { class: "card" }, S.cats.map((c, i) => h("div", { class: "prow" },
      h("span", { class: "mut" }, `${i + 1}.`),
      h("div", { class: "grow" }, h("b", {}, c.name), c.prize ? h("div", { class: "mut sm" }, `Premio: ${c.prize}`) : null)))));
}

// ---------- votación: a cada persona, una categoría distinta ----------
function votingView() {
  const others = S.parts.filter((p) => p.id !== S.me.pid);
  const total = others.length;
  const used = S.picks.filter((pk) => others.some((o) => o.id === pk.pid)).length;
  const catName = (id) => S.cats.find((c) => c.id === id)?.name || "?";

  const rows = others.map((p) => {
    const pk = S.picks.find((x) => x.pid === p.id);
    return h("div", { class: "vrow" }, avatar(p.name),
      h("div", { class: "grow" }, h("b", {}, p.name),
        pk ? h("div", { class: "ok sm" }, `✔ ${catName(pk.cid)}`) : h("div", { class: "mut sm" }, "Sin categoría todavía")),
      pk
        ? h("div", { class: "row" },
          h("button", { class: "ghost sm", onclick: () => pickCategory(p) }, "Cambiar"),
          h("button", { class: "ghost sm danger", onclick: () => savePicks(S.picks.filter((x) => x.pid !== p.id)) }, "Quitar"))
        : h("button", { class: "btn sm", onclick: () => pickCategory(p) }, "Asignar"));
  });

  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, "¡A votar!"),
      h("p", { class: "lead" }, "Para cada persona del grupo, elige en qué categoría la nominas. Cada categoría solo la puedes usar una vez, y cada persona recibe un solo voto tuyo."),
      h("span", { class: "pill" }, `Votos: ${used}/${total}`),
      h("p", { class: "mut sm" }, "Tus votos son secretos y puedes cambiarlos hasta que cierre la votación.")),
    total ? h("div", { class: "card" }, rows) : h("div", { class: "card" }, h("p", { class: "mut" }, "Aún no hay más personas inscritas.")));
}

function pickCategory(person) {
  const taken = new Set(S.picks.filter((p) => p.pid !== person.id).map((p) => p.cid));
  const options = S.cats.filter((c) => !taken.has(c.id));
  const dlg = h("dialog", { class: "sheet" },
    h("h3", {}, `¿En qué categoría nominas a ${person.name}?`),
    h("p", { class: "mut sm" }, "Solo aparecen las categorías que aún no has usado."),
    h("div", { class: "chips scroll" }, options.length
      ? options.map((c) => h("button", {
        class: "chip",
        onclick: () => {
          dlg.close();
          savePicks([...S.picks.filter((x) => x.pid !== person.id), { pid: person.id, cid: c.id }]);
        },
      }, c.name))
      : h("p", { class: "mut" }, "Ya usaste todas las categorías.")),
    h("button", { class: "ghost", onclick: () => dlg.close() }, "Cancelar"));
  document.body.append(dlg);
  dlg.addEventListener("close", () => dlg.remove());
  dlg.showModal();
}

async function savePicks(picks) {
  try {
    await setDoc(doc(db, "votes", S.me.pid), { uid: S.user.uid, proof: S.me.proof, picks, at: serverTimestamp() });
    S.picks = picks;
    S.lastKey = "";
    render();
    toast("Voto guardado ✔");
  } catch (e) { writeError(e); }
}

boot();
