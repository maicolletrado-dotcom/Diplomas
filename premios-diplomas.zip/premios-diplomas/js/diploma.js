import { SIGNER_NAME, SIGNER_TITLE } from "./config.js";

export const DIPLOMA_W = 1600;
export const DIPLOMA_H = 1130;

const SERIF = '"Playfair Display", Georgia, "Times New Roman", serif';
const SCRIPT = '"Great Vibes", "Brush Script MT", "Snell Roundhand", cursive';
const CAPS = 'Cinzel, "Playfair Display", Georgia, serif';
const GOLD = "#a8741a";
const GOLD_L = "#e8c76a";
const INK = "#2d2218";

const PHRASES = [
  "Reconocimiento otorgado sin sobornos comprobados y con total transparencia democrática.",
  "Por mérito propio, por voluntad popular y porque a alguien le tocaba.",
  "El jurado deliberó varios minutos por el grupo de WhatsApp y llegó a esta conclusión inapelable.",
  "Este honor se acepta con humildad, aunque se presumirá en cada reunión futura.",
  "Válido en todo el grupo, no reembolsable y sujeto a burlas cariñosas.",
  "Un título merecido que la historia de la amistad sabrá recordar.",
  "Se entrega con orgullo, con cariño y con una pizca de venganza amistosa.",
  "Su talento para esto ya era leyenda. Hoy es oficial.",
];
const PHRASES_ZERO = [
  "Nadie votó, pero el universo insistió: el destino y el sorteo también cuentan.",
  "Ganado por designio del azar, que en esta pandilla tiene voto y voz.",
  "Los votos no alcanzaron, pero la fama lo encontró igual.",
];

function hash(s) {
  let h = 2166136261;
  for (const c of String(s)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

export function phraseFor(o) {
  const list = o.votes > 0 ? PHRASES : PHRASES_ZERO;
  return list[hash(`${o.cid}|${o.pid}`) % list.length];
}

function wrap(ctx, text, maxW) {
  const lines = [];
  let line = "";
  for (const w of String(text).split(/\s+/)) {
    const t = line ? `${line} ${w}` : w;
    if (ctx.measureText(t).width > maxW && line) { lines.push(line); line = w; } else line = t;
  }
  if (line) lines.push(line);
  return lines;
}

/** Reduce el tamaño hasta que el texto quepa en `maxLines` líneas de ancho `maxW`. */
function fit(ctx, text, fontFn, maxW, size, min, maxLines = 1) {
  for (let s = size; s >= min; s -= 2) {
    ctx.font = fontFn(s);
    const lines = wrap(ctx, text, maxW);
    if (lines.length <= maxLines) return { size: s, lines };
  }
  ctx.font = fontFn(min);
  return { size: min, lines: wrap(ctx, text, maxW).slice(0, maxLines) };
}

function spaced(ctx, t, cx, y, sp) {
  const chars = [...t];
  const ws = chars.map((c) => ctx.measureText(c).width);
  const total = ws.reduce((a, b) => a + b, 0) + sp * (chars.length - 1);
  let x = cx - total / 2;
  const prev = ctx.textAlign;
  ctx.textAlign = "left";
  chars.forEach((c, i) => { ctx.fillText(c, x, y); x += ws[i] + sp; });
  ctx.textAlign = prev;
}

function corner(ctx, x, y, sx, sy) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(sx, sy);
  ctx.strokeStyle = GOLD;
  ctx.lineWidth = 5;
  ctx.beginPath(); ctx.moveTo(0, 120); ctx.lineTo(0, 0); ctx.lineTo(120, 0); ctx.stroke();
  ctx.beginPath(); ctx.arc(34, 34, 16, 0, Math.PI * 2);
  ctx.fillStyle = GOLD_L; ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(34, 34, 5, 0, Math.PI * 2); ctx.fillStyle = GOLD; ctx.fill();
  ctx.restore();
}

function divider(ctx, cx, y, w) {
  ctx.strokeStyle = GOLD; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(cx - w / 2, y); ctx.lineTo(cx - 20, y); ctx.moveTo(cx + 20, y); ctx.lineTo(cx + w / 2, y); ctx.stroke();
  ctx.fillStyle = GOLD;
  ctx.beginPath(); ctx.moveTo(cx, y - 9); ctx.lineTo(cx + 9, y); ctx.lineTo(cx, y + 9); ctx.lineTo(cx - 9, y); ctx.closePath(); ctx.fill();
}

function seal(ctx, cx, cy, r, label) {
  ctx.fillStyle = "#8c1c2b";
  for (const s of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(cx + s * 12, cy + 30);
    ctx.lineTo(cx + s * 58, cy + r + 32);
    ctx.lineTo(cx + s * 34, cy + r + 22);
    ctx.lineTo(cx + s * 14, cy + r + 36);
    ctx.lineTo(cx - s * 8, cy + 36);
    ctx.closePath(); ctx.fill();
  }
  const pts = 28;
  ctx.beginPath();
  for (let i = 0; i < pts * 2; i++) {
    const a = (i * Math.PI) / pts;
    const rr = i % 2 ? r * 0.88 : r;
    ctx.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
  }
  ctx.closePath();
  const g = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.3, 6, cx, cy, r);
  g.addColorStop(0, "#fff3c2"); g.addColorStop(0.6, GOLD_L); g.addColorStop(1, "#b98a2b");
  ctx.fillStyle = g; ctx.fill();
  ctx.strokeStyle = "#8a5a10"; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(cx, cy, r * 0.68, 0, Math.PI * 2); ctx.stroke();
  ctx.fillStyle = "#6b4308"; ctx.textAlign = "center";
  ctx.font = `700 ${Math.round(r * 0.5)}px ${CAPS}`;
  ctx.fillText("★", cx, cy - r * 0.08);
  ctx.font = `700 ${Math.round(r * 0.3)}px ${CAPS}`;
  ctx.fillText(label, cx, cy + r * 0.32);
}

/**
 * Dibuja el diploma en un contexto 2D de DIPLOMA_W × DIPLOMA_H.
 * o: { name, category, prize, votes, event, date, n, total, cid, pid, signer, signerTitle }
 */
export function drawDiploma(ctx, o) {
  const W = DIPLOMA_W, H = DIPLOMA_H, cx = W / 2;
  ctx.save();
  ctx.textBaseline = "alphabetic";
  ctx.textAlign = "center";

  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, "#fffaf0"); bg.addColorStop(1, "#f3e6c4");
  ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);

  const fg = ctx.createLinearGradient(0, 0, W, 0);
  fg.addColorStop(0, GOLD); fg.addColorStop(0.5, GOLD_L); fg.addColorStop(1, GOLD);
  ctx.strokeStyle = fg; ctx.lineWidth = 14; ctx.strokeRect(40, 40, W - 80, H - 80);
  ctx.strokeStyle = GOLD; ctx.lineWidth = 3; ctx.strokeRect(70, 70, W - 140, H - 140);
  corner(ctx, 86, 86, 1, 1); corner(ctx, W - 86, 86, -1, 1);
  corner(ctx, 86, H - 86, 1, -1); corner(ctx, W - 86, H - 86, -1, -1);

  ctx.fillStyle = GOLD;
  ctx.font = `700 54px ${CAPS}`;
  spaced(ctx, "DIPLOMA DE HONOR", cx, 150, 8);
  ctx.fillStyle = INK;
  ctx.font = `italic 500 30px ${SERIF}`;
  ctx.fillText(`Premios ${o.event || ""}`.trim(), cx, 198);
  divider(ctx, cx, 232, 600);

  ctx.fillStyle = INK;
  ctx.font = `500 30px ${SERIF}`;
  ctx.fillText("El honorable jurado de amigos reconoce a", cx, 296);

  const nm = fit(ctx, o.name, (s) => `${s}px ${SCRIPT}`, 1200, 124, 60);
  ctx.font = `${nm.size}px ${SCRIPT}`; ctx.fillStyle = "#6b4308";
  ctx.fillText(nm.lines[0], cx, 424);
  ctx.strokeStyle = GOLD; ctx.lineWidth = 2;
  const half = Math.max(420, ctx.measureText(nm.lines[0]).width / 2 + 30);
  ctx.beginPath(); ctx.moveTo(cx - half, 448); ctx.lineTo(cx + half, 448); ctx.stroke();

  ctx.fillStyle = INK;
  ctx.font = `500 30px ${SERIF}`;
  ctx.fillText("por su destacada trayectoria en la categoría", cx, 506);

  const cat = fit(ctx, `“${o.category}”`, (s) => `700 ${s}px ${SERIF}`, 1180, 70, 36, 2);
  ctx.font = `700 ${cat.size}px ${SERIF}`; ctx.fillStyle = GOLD;
  let y = 582;
  for (const ln of cat.lines) { ctx.fillText(ln, cx, y); y += cat.size * 1.15; }

  ctx.fillStyle = INK;
  ctx.font = `italic 500 28px ${SERIF}`;
  y += 4;
  for (const ln of wrap(ctx, phraseFor(o), 1000).slice(0, 3)) { ctx.fillText(ln, cx, y); y += 38; }

  if (o.prize) {
    ctx.font = `700 30px ${SERIF}`; ctx.fillStyle = "#6b4308";
    const pz = wrap(ctx, `Premio: ${o.prize}`, 1100)[0];
    ctx.fillText(pz, cx, y + 14);
  }

  // Pie: fecha · sello · firma
  const by = 950;
  ctx.fillStyle = INK; ctx.font = `500 32px ${SERIF}`;
  ctx.fillText(o.date || "", 330, by - 6);
  ctx.strokeStyle = GOLD; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(150, by + 12); ctx.lineTo(510, by + 12); ctx.stroke();
  ctx.font = `600 20px ${CAPS}`; ctx.fillStyle = GOLD;
  spaced(ctx, "FECHA", 330, by + 44, 4);

  const sg = fit(ctx, o.signer || SIGNER_NAME, (s) => `${s}px ${SCRIPT}`, 340, 70, 36);
  ctx.font = `${sg.size}px ${SCRIPT}`; ctx.fillStyle = INK;
  ctx.fillText(sg.lines[0], 1270, by - 6);
  ctx.beginPath(); ctx.moveTo(1090, by + 12); ctx.lineTo(1450, by + 12); ctx.stroke();
  ctx.font = `600 20px ${CAPS}`; ctx.fillStyle = GOLD;
  spaced(ctx, (o.signerTitle || SIGNER_TITLE).toUpperCase(), 1270, by + 44, 3);

  seal(ctx, cx, 935, 56, o.n ? `Nº ${String(o.n).padStart(2, "0")}` : "");

  ctx.fillStyle = "#7a6a52"; ctx.font = `500 20px ${SERIF}`;
  const foot = `${o.n && o.total ? `Diploma ${o.n} de ${o.total} · ` : ""}${o.votes} voto${o.votes === 1 ? "" : "s"} del jurado`;
  ctx.fillText(foot, cx, 1048);
  ctx.restore();
}

/** Arma las opciones del diploma a partir de un ítem revelado. */
export function buildDiplomaOpts({ item, cats, parts, state, total }) {
  const cat = cats.find((c) => c.id === item.cid);
  const part = parts.find((p) => p.id === item.pid);
  return {
    cid: item.cid,
    pid: item.pid,
    name: part?.name || "—",
    category: cat?.name || "—",
    prize: cat?.prize || "",
    votes: item.votes || 0,
    n: item.n,
    total: total || cats.length,
    event: state?.eventTitle || "",
    date: state?.eventDate || new Date().toLocaleDateString("es-CO", { day: "numeric", month: "long", year: "numeric" }),
  };
}

// ---------- Solo navegador ----------
export async function loadFonts() {
  try {
    await Promise.all([
      document.fonts.load(`124px "Great Vibes"`),
      document.fonts.load(`700 60px "Playfair Display"`),
      document.fonts.load(`italic 500 28px "Playfair Display"`),
      document.fonts.load(`500 30px "Playfair Display"`),
      document.fonts.load(`700 50px Cinzel`),
    ]);
  } catch { /* si fallan las fuentes se usan las de respaldo */ }
}

export async function diplomaCanvas(o) {
  await loadFonts();
  const c = document.createElement("canvas");
  c.width = DIPLOMA_W; c.height = DIPLOMA_H;
  drawDiploma(c.getContext("2d"), o);
  return c;
}

export const canvasBlob = (c) => new Promise((res) => c.toBlob(res, "image/png"));

export async function shareOrDownload(blob, filename) {
  const file = new File([blob], filename, { type: "image/png" });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try { await navigator.share({ files: [file], title: "Mi diploma" }); return; }
    catch (e) { if (e.name === "AbortError") return; }
  }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = filename;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
