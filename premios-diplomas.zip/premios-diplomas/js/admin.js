import {
  db, auth, googleSignIn, onAuthStateChanged, signOut,
  doc, collection, setDoc, deleteDoc, onSnapshot, writeBatch,
} from "./firebase.js";
import { tally, assign, mulberry32, normalizeText } from "./assign.js";
import { buildDiplomaOpts, diplomaCanvas } from "./diploma.js";
import { h, toast, avatar, slug, confetti, openDiploma } from "./ui.js";

const root = document.getElementById("app");

const PHASES = [
  ["setup", "1 · Inscripción"],
  ["proposing", "2 · Propuestas de categorías"],
  ["consolidating", "3 · Armando las categorías"],
  ["consolidated", "4 · Categorías consolidadas"],
  ["voting", "5 · Votación"],
  ["results", "6 · Reparto"],
  ["ceremony", "7 · Presentación (solo tú)"],
  ["done", "8 · Diplomas publicados"],
];

const D = { state: {}, parts: [], claimed: new Set(), proposals: [], votes: [], cats: [], results: null, cer: null };
const S = { tab: "resumen" };
let tabBox, nav;

const st = () => ({
  phase: "setup", eventTitle: "de la Pandilla", eventDate: "",
  proposalsPerPerson: 5, diplomasPerPerson: 2, registrationOpen: true, ...D.state,
});
const target = () => D.parts.length * st().diplomasPerPerson;
// Cuántas propuestas distintas ha enviado una persona
const propCount = (pid) =>
  new Set((D.proposals.find((p) => p.id === pid)?.items || []).map(normalizeText).filter(Boolean)).size;
const pendingProposals = () => D.parts.filter((p) => propCount(p.id) < st().proposalsPerPerson);
const pname = (id) => D.parts.find((p) => p.id === id)?.name || "?";
const byName = (a, b) => a.name.localeCompare(b.name, "es");
const run = async (fn) => { try { await fn(); } catch (e) { toast(`Error: ${e.code || e.message}`, true); } };

const TABS = [
  ["resumen", "Resumen", ["state", "parts", "cats"]],
  ["personas", "Personas", ["parts", "claimed", "state"]],
  ["propuestas", "Propuestas", ["proposals", "parts", "cats", "state"]],
  ["categorias", "Categorías", ["cats", "parts", "state"]],
  ["votos", "Votos", ["votes", "cats", "parts", "state"]],
  ["resultados", "Resultados", ["results", "votes", "cats", "parts", "state"]],
  ["presentacion", "Presentación", ["cer", "results", "cats", "parts", "state"]],
];

// ---------- acceso ----------
let started = false;
onAuthStateChanged(auth, (u) => {
  if (u && !u.isAnonymous) start();
  else loginScreen();
});

function loginScreen() {
  root.replaceChildren(h("div", { class: "card" },
    h("h1", {}, "🎓 Panel del admin"),
    h("p", { class: "mut" }, "Entra con la cuenta de Google del administrador."),
    h("button", { class: "btn", onclick: () => run(googleSignIn) }, "Entrar con Google")));
}

function start() {
  if (started) return;
  started = true;
  shell();
  const err = (e) => toast(`Sin permiso o sin conexión: ${e.code || e.message}. ¿Es la cuenta correcta en firestore.rules?`, true);
  const sub = (ref, key, map) => onSnapshot(ref, (s) => { D[key] = map(s); changed(key); }, err);
  const docs = (s) => s.docs.map((d) => ({ id: d.id, ...d.data() }));
  onSnapshot(doc(db, "config", "state"), (s) => {
    if (!s.exists()) { run(() => setDoc(doc(db, "config", "state"), { phase: "setup", ...st() }, { merge: true })); return; }
    D.state = s.data(); changed("state");
    if (D.state.registrationOpen === undefined) setState({ registrationOpen: true });
  }, err);
  sub(collection(db, "participants"), "parts", (s) => docs(s).sort(byName));
  sub(collection(db, "claimed"), "claimed", (s) => new Set(s.docs.map((d) => d.id)));
  sub(collection(db, "proposals"), "proposals", docs);
  sub(collection(db, "votes"), "votes", docs);
  sub(collection(db, "categories"), "cats", (s) => docs(s).sort((a, b) => a.order - b.order));
  sub(doc(db, "admin", "results"), "results", (s) => (s.exists() ? s.data() : null));
  sub(doc(db, "config", "ceremony"), "cer", (s) => (s.exists() ? s.data() : null));
}

function shell() {
  nav = h("nav", { class: "tabs" });
  tabBox = h("div");
  root.replaceChildren(
    h("header", { class: "top" }, h("h1", {}, "🎓 Panel del admin"),
      h("button", { class: "ghost sm", onclick: () => signOut(auth) }, "Salir")),
    nav, tabBox);
  drawNav(); renderTab();
}
function drawNav() {
  nav.replaceChildren(...TABS.map(([k, label]) =>
    h("button", { class: S.tab === k ? "on" : "", onclick: () => { S.tab = k; drawNav(); renderTab(); } }, label)));
}
function changed(key) {
  const t = TABS.find((x) => x[0] === S.tab);
  if (tabBox && t && t[2].includes(key)) renderTab();
}
function renderTab() {
  const fn = { resumen, personas, propuestas, categorias, votos, resultados, presentacion }[S.tab];
  tabBox.replaceChildren(fn());
}

// ---------- helpers de escritura ----------
const setState = (patch) => run(() => setDoc(doc(db, "config", "state"), patch, { merge: true }));
const siteUrl = () => new URL("./", location.href).href;

// ---------- RESUMEN ----------
function resumen() {
  const s = st();
  const i = PHASES.findIndex((p) => p[0] === s.phase);
  const blocked = s.phase === "results" ? "Pasa a la presentación desde la pestaña Resultados." :
    s.phase === "ceremony" ? "Cuando termines tu presentación, publica los diplomas desde la pestaña Presentación." : "";

  const goNext = () => {
    const next = PHASES[i + 1][0];
    const patch = { phase: next };
    if (next === "consolidating") {
      const pend = pendingProposals();
      const warn = pend.length ? `\n\n⚠ Aún no completan sus ${s.proposalsPerPerson} propuestas: ${pend.map((p) => p.name).join(", ")}.` : "";
      if (!confirm(`Se cerrarán las inscripciones con ${D.parts.length} personas (se necesitan ${target()} categorías: ${D.parts.length} × ${s.diplomasPerPerson}) y ya nadie podrá enviar propuestas.${warn}\n\n¿Continuar?`)) return;
      patch.registrationOpen = false;
    }
    if (next === "consolidated" && D.cats.length !== target() &&
      !confirm(`Tienes ${D.cats.length} categorías y se necesitan ${target()} (${D.parts.length} personas × ${s.diplomasPerPerson}). ¿Publicarlas igual?`)) return;
    setState(patch);
  };

  const fields = {
    eventTitle: h("input", { value: s.eventTitle, placeholder: "de la Pandilla" }),
    eventDate: h("input", { value: s.eventDate, placeholder: "12 de diciembre de 2026" }),
    proposalsPerPerson: h("input", { type: "number", min: 1, max: 10, value: s.proposalsPerPerson }),
    diplomasPerPerson: h("input", { type: "number", min: 1, max: 5, value: s.diplomasPerPerson }),
  };
  const lab = (t, el) => h("label", { class: "sm mut" }, t, el);

  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, "Fase actual"),
      h("ol", { class: "steps" }, PHASES.map(([k, l]) => h("li", { class: k === s.phase ? "on" : "" }, l))),
      h("div", { class: "row" },
        h("button", { class: "ghost", disabled: i === 0, onclick: () => setState({ phase: PHASES[i - 1][0] }) }, "◀ Fase anterior"),
        h("button", { class: "btn", disabled: i >= PHASES.length - 1 || !!blocked, onclick: goNext }, "Siguiente fase ▶")),
      blocked ? h("p", { class: "mut sm" }, blocked) : null),
    h("div", { class: "card" }, h("h3", {}, "Ajustes"),
      h("div", { class: "grid2" },
        lab("Nombre del evento (sale en el diploma: “Premios …”)", fields.eventTitle),
        lab("Fecha en los diplomas (opcional)", fields.eventDate),
        lab("Propuestas por persona", fields.proposalsPerPerson),
        lab("Diplomas por persona", fields.diplomasPerPerson)),
      h("p", { class: "mut sm" }, `Con ${D.parts.length} personas × ${s.diplomasPerPerson} diplomas necesitas ${target()} categorías. En la votación cada persona nomina una vez a cada una de las demás (${Math.max(0, D.parts.length - 1)} votos por persona, ${D.parts.length * Math.max(0, D.parts.length - 1)} en total), así todos reciben votos.`),
      h("button", {
        class: "btn",
        onclick: () => setState({
          eventTitle: fields.eventTitle.value.trim(), eventDate: fields.eventDate.value.trim(),
          proposalsPerPerson: +fields.proposalsPerPerson.value || 5,
          diplomasPerPerson: +fields.diplomasPerPerson.value || 2,
        }).then?.(() => toast("Ajustes guardados ✔")),
      }, "Guardar ajustes")));
}

// ---------- PERSONAS ----------
function personas() {
  const s = st();
  const open = s.registrationOpen !== false;
  const nameInput = h("input", { placeholder: "Agregar a alguien a mano (opcional)" });

  const addPerson = () => run(async () => {
    const name = nameInput.value.trim().replace(/\s+/g, " ");
    if (name.length < 2) return toast("Escribe el nombre.", true);
    const id = slug(name);
    if (D.parts.some((p) => p.id === id)) return toast("Ese nombre ya existe.", true);
    await setDoc(doc(db, "participants", id), { name });
    nameInput.value = "";
    toast("Agregado ✔ (creará su clave al entrar con ese nombre)");
  });

  const remove = (p) => confirm(`¿Quitar a ${p.name}? Se borran también sus propuestas y votos.`) && run(async () => {
    const batch = writeBatch(db);
    for (const col of ["participants", "secrets", "claimed", "proposals", "votes"]) batch.delete(doc(db, col, p.id));
    await batch.commit();
    toast("Persona eliminada ✔");
  });

  const resetKey = (p) => confirm(`¿Reiniciar la clave de ${p.name}? Podrá crear una nueva entrando con su nombre.`) && run(async () => {
    const batch = writeBatch(db);
    batch.delete(doc(db, "secrets", p.id));
    batch.delete(doc(db, "claimed", p.id));
    await batch.commit();
    toast("Clave reiniciada ✔");
  });

  const msg = `Hola 👋 Ya están abiertos los Premios ${s.eventTitle}. Entra aquí, escribe tu nombre y crea tu clave:\n${siteUrl()}`;
  const ready = D.parts.filter((p) => D.claimed.has(p.id)).length;

  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, "Inscripciones"),
      h("p", { class: "mut sm" }, "Cada amigo escribe su nombre y una clave la primera vez que entra y queda registrado. Cierra las inscripciones cuando ya estén todos, para que nadie más (ni un desconocido con el enlace) pueda entrar."),
      h("p", {}, open ? h("span", { class: "badge g" }, "abiertas") : h("span", { class: "badge y" }, "cerradas")),
      h("button", { class: open ? "ghost" : "btn", onclick: () => setState({ registrationOpen: !open }) }, open ? "🔒 Cerrar inscripciones" : "🔓 Abrir inscripciones"),
      !open ? h("p", { class: "mut sm" }, "Con las inscripciones cerradas, quien ya se registró sigue entrando con su nombre y su clave.") : null),
    h("div", { class: "card" }, h("h3", {}, "Invitación"),
      h("p", { class: "mut sm" }, `Enlace para tus amigos: ${siteUrl()}`),
      h("button", { class: "btn", onclick: () => window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, "_blank") }, "📲 Compartir por WhatsApp"),
      h("button", { class: "ghost", onclick: () => navigator.clipboard?.writeText(msg).then(() => toast("Mensaje copiado ✔")) }, "Copiar mensaje")),
    h("div", { class: "card" }, h("h3", {}, `Registrados: ${D.parts.length}`),
      D.parts.length ? h("p", { class: "mut sm" }, `${ready} con clave creada. Si alguien olvidó su clave, o alguien se registró con el nombre de otro por error, reinicia esa clave o quita a la persona.`) : h("p", { class: "mut" }, "Aún no se ha registrado nadie."),
      D.parts.map((p) => h("div", { class: "prow" }, avatar(p.name),
        h("div", { class: "grow" }, p.name),
        D.claimed.has(p.id) ? h("span", { class: "badge g" }, "con clave") : h("span", { class: "badge" }, "sin clave"),
        D.claimed.has(p.id) ? h("button", { class: "ghost sm", onclick: () => resetKey(p) }, "🔄") : null,
        h("button", { class: "ghost sm danger", onclick: () => remove(p) }, "🗑"))),
      h("div", { class: "row" }, nameInput, h("button", { class: "btn", onclick: addPerson }, "Agregar"))));
}

// ---------- PROPUESTAS ----------
function grouped() {
  const m = new Map();
  for (const pr of D.proposals) {
    for (const it of pr.items || []) {
      const k = normalizeText(it);
      if (!k) continue;
      const g = m.get(k) || { key: k, text: it, authors: [] };
      g.authors.push(pname(pr.id));
      m.set(k, g);
    }
  }
  return [...m.values()].sort((a, b) => b.authors.length - a.authors.length || a.text.localeCompare(b.text, "es"));
}

const addCat = (name) => run(async () => {
  const order = Math.max(0, ...D.cats.map((c) => c.order || 0)) + 1;
  const id = `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
  await setDoc(doc(db, "categories", id), { name: name.trim(), order, prize: "" });
});

function propuestas() {
  const s = st();
  const need = s.proposalsPerPerson;
  const list = grouped();
  const have = new Set(D.cats.map((c) => normalizeText(c.name)));
  const manual = h("input", { placeholder: "Agregar una categoría propia…" });
  const pending = pendingProposals();
  const doneCount = D.parts.length - pending.length;

  const remind = () => {
    const names = pending.map((p) => p.name).join(", ");
    const msg = `Hola 👋 Todavía faltan por escribir sus ${need} categorías para los Premios ${s.eventTitle}: ${names}.\nEntra con tu nombre y tu clave: ${siteUrl()}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, "_blank");
  };

  const row = (p) => {
    const c = propCount(p.id);
    const badge = c >= need ? h("span", { class: "badge g" }, `✅ ${c}/${need}`)
      : c > 0 ? h("span", { class: "badge y" }, `⚠️ ${c}/${need}`)
        : h("span", { class: "badge" }, `⏳ 0/${need}`);
    return h("div", { class: "prow" }, avatar(p.name), h("div", { class: "grow" }, p.name), badge);
  };

  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, `Checklist de propuestas: ${doneCount}/${D.parts.length} completas`),
      h("p", { class: "mut sm" }, `Cada persona inscrita debe enviar exactamente ${need} categorías distintas (la app no las deja guardar con menos).`),
      D.parts.length ? D.parts.map(row) : h("p", { class: "mut" }, "Aún no hay personas inscritas."),
      pending.length ? h("button", { class: "btn", onclick: remind }, `📲 Recordar a los ${pending.length} pendientes por WhatsApp`) : null,
      D.parts.length && !pending.length ? h("p", { class: "ok" }, "¡Todos completaron sus propuestas! Ya puedes pasar a “Armando las categorías”.") : null),
    h("div", { class: "card" }, h("h3", {}, `Ideas recibidas (${list.length})`),
      h("p", { class: "mut sm" }, `Categorías escogidas: ${D.cats.length}/${target()}. Toca ＋ para agregar una al listado oficial (pestaña Categorías).`),
      list.length ? list.map((g) => h("div", { class: "prow" },
        h("div", { class: "grow" }, h("b", {}, g.text),
          h("div", { class: "mut sm" }, `${g.authors.length > 1 ? `×${g.authors.length} · ` : ""}${g.authors.join(", ")}`)),
        have.has(g.key)
          ? h("span", { class: "badge g" }, "agregada")
          : h("button", { class: "btn sm", onclick: () => addCat(g.text) }, "＋")))
        : h("p", { class: "mut" }, "Aún no llega ninguna propuesta."),
      h("div", { class: "row" }, manual,
        h("button", { class: "btn", onclick: () => { if (manual.value.trim()) { addCat(manual.value); manual.value = ""; } } }, "Agregar"))));
}

// ---------- CATEGORÍAS ----------
function categorias() {
  const n = D.cats.length, need = target();
  const swap = (a, b) => run(async () => {
    const batch = writeBatch(db);
    batch.update(doc(db, "categories", a.id), { order: b.order });
    batch.update(doc(db, "categories", b.id), { order: a.order });
    await batch.commit();
  });
  const rows = D.cats.map((c, i) => h("div", { class: "prow" },
    h("span", { class: "mut" }, `${i + 1}.`),
    h("div", { class: "grow" },
      h("input", { value: c.name, onchange: (e) => run(() => setDoc(doc(db, "categories", c.id), { name: e.target.value.trim() }, { merge: true })) }),
      h("input", { value: c.prize || "", placeholder: "Premio (opcional): ej. un helado, un abrazo…", onchange: (e) => run(() => setDoc(doc(db, "categories", c.id), { prize: e.target.value.trim() }, { merge: true })) })),
    h("div", { class: "row" },
      h("button", { class: "ghost sm", disabled: i === 0, onclick: () => swap(c, D.cats[i - 1]) }, "↑"),
      h("button", { class: "ghost sm", disabled: i === n - 1, onclick: () => swap(c, D.cats[i + 1]) }, "↓"),
      h("button", { class: "ghost sm danger", onclick: () => confirm(`¿Quitar “${c.name}”?`) && run(() => deleteDoc(doc(db, "categories", c.id))) }, "🗑"))));
  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, "Categorías oficiales"),
      h("span", { class: `pill` }, `${n}/${need}`),
      h("p", { class: "mut sm" }, n === need ? "Justo las necesarias ✔" : n < need ? `Faltan ${need - n} para que todos reciban ${st().diplomasPerPerson} diplomas.` : `Sobran ${n - need}: quita algunas.`)),
    h("div", { class: "card" }, rows.length ? rows : h("p", { class: "mut" }, "Agrega categorías desde la pestaña Propuestas.")));
}

// ---------- VOTOS ----------
const tallyNow = () => tally({ parts: D.parts, cats: D.cats, votes: D.votes });

function votos() {
  const need = Math.max(0, D.parts.length - 1);
  const { counts, voted, invalid } = tallyNow();
  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, "Participación"),
      D.parts.map((p) => h("div", { class: "prow" }, avatar(p.name),
        h("div", { class: "grow" }, p.name),
        voted[p.id] ? h("span", { class: `badge ${voted[p.id] >= need ? "g" : "y"}` }, `${voted[p.id]}/${need} votos`) : h("span", { class: "badge" }, "pendiente"))),
      invalid ? h("p", { class: "mut sm" }, `${invalid} voto(s) inválidos se ignoran.`) : null),
    h("div", { class: "card" }, h("h3", {}, "Conteo en vivo (solo tú lo ves)"),
      h("table", {}, D.cats.map((c) => {
        const row = Object.entries(counts[c.id] || {}).sort((a, b) => b[1] - a[1]);
        return h("tr", {}, h("td", {}, h("b", {}, c.name)),
          h("td", { class: "mut" }, row.length ? row.map(([pid, n]) => `${pname(pid)} ${n}`).join(" · ") : "—"));
      }))));
}

// ---------- RESULTADOS ----------
function saveResults(items, seed) {
  return run(() => setDoc(doc(db, "admin", "results"), { items, seed }));
}

function compute(seed) {
  const s = st();
  const { counts } = tallyNow();
  if (D.cats.length > target()) return toast(`Hay ${D.cats.length} categorías y solo ${target()} cupos.`, true);
  const items = assign({ parts: D.parts, cats: D.cats, counts, diplomasPerPerson: s.diplomasPerPerson, seed });
  return saveResults(items, seed);
}

function resultados() {
  const s = st();
  if (!D.results) {
    return h("div", { class: "card" }, h("h3", {}, "Reparto de diplomas"),
      h("p", { class: "mut" }, `Se asigna cada categoría a una persona maximizando los votos, con máximo ${s.diplomasPerPerson} diplomas por persona. Los empates y las categorías sin votos se sortean.`),
      h("button", { class: "btn", onclick: () => compute(Date.now() % 100000) }, "🧮 Calcular reparto"));
  }
  const { counts } = tallyNow();
  const items = D.results.items.filter((it) => D.cats.some((c) => c.id === it.cid));
  const catName = (id) => D.cats.find((c) => c.id === id)?.name || "?";
  const perPerson = Object.fromEntries(D.parts.map((p) => [p.id, 0]));
  items.forEach((it) => { perPerson[it.pid] = (perPerson[it.pid] || 0) + 1; });
  const uneven = D.parts.some((p) => perPerson[p.id] !== s.diplomasPerPerson);

  const change = (idx, pid) => {
    const next = items.map((it) => ({ ...it }));
    next[idx].pid = pid;
    next[idx].votes = counts[next[idx].cid]?.[pid] || 0;
    saveResults(next, D.results.seed);
  };
  const shuffle = () => {
    const rnd = mulberry32(Date.now() % 100000);
    const a = items.map((x) => ({ ...x }));
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    saveResults(a, D.results.seed);
  };
  const toPresentation = () => {
    if (uneven && !confirm("No todos tienen exactamente el mismo número de diplomas. ¿Continuar igual?")) return;
    run(async () => {
      // Los amigos siguen sin ver nada: solo cambian a la pantalla de “sorpresa”
      await deleteDoc(doc(db, "config", "ceremony"));
      await setDoc(doc(db, "config", "state"), { phase: "ceremony" }, { merge: true });
      S.tab = "presentacion"; drawNav(); renderTab();
    });
  };
  const peekDiploma = (it, idx) =>
    openDiploma(buildDiplomaOpts({ item: { ...it, n: idx + 1 }, cats: D.cats, parts: D.parts, state: s, total: items.length }));

  const badge = (it) => it.votes === 0 ? h("span", { class: "badge y" }, "sorteo (sin votos)")
    : it.topPids?.includes(it.pid) ? h("span", { class: "badge g" }, "más votado")
      : h("span", { class: "badge y" }, `por reparto · más votado: ${it.topPids.map(pname).join("/")} (${it.topVotes})`);

  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, "Reparto propuesto"),
      h("div", { class: "row" },
        h("button", { class: "ghost", onclick: () => compute(Date.now() % 100000) }, "🎲 Re-sortear empates"),
        h("button", { class: "ghost", onclick: shuffle }, "🔀 Mezclar orden de la presentación"),
        h("button", { class: "btn", onclick: toPresentation }, "🎬 Ir a la presentación")),
      h("p", { class: "mut sm" }, "Solo tú ves esto. Puedes cambiar el ganador de cualquier categoría; revisa que cada persona quede con el mismo número de diplomas.")),
    h("div", { class: "card" }, h("h3", {}, "Diplomas por persona"),
      h("div", { class: "row" }, D.parts.map((p) =>
        h("span", { class: `badge ${perPerson[p.id] === s.diplomasPerPerson ? "g" : "y"}` }, `${p.name}: ${perPerson[p.id]}`)))),
    h("div", { class: "card" }, h("table", {}, items.map((it, idx) => h("tr", {},
      h("td", {}, h("span", { class: "mut" }, `${idx + 1}. `), h("b", {}, catName(it.cid)), h("div", {}, badge(it))),
      h("td", {}, h("select", { onchange: (e) => change(idx, e.target.value) },
        D.parts.map((p) => h("option", { value: p.id, selected: p.id === it.pid },
          `${p.name} (${counts[it.cid]?.[p.id] || 0})`)))),
      h("td", {}, h("button", { class: "ghost sm", onclick: () => peekDiploma(it, idx) }, "🎓")))))));
}

// ---------- PRESENTACIÓN (solo el admin ve los resultados) ----------
function presentacion() {
  const s = st();
  if (!D.results) {
    return h("div", { class: "card" }, h("h3", {}, "Presentación"),
      h("p", { class: "mut" }, "Primero calcula el reparto en la pestaña Resultados."));
  }
  const items = D.results.items.filter((it) => D.cats.some((c) => c.id === it.cid));
  const published = s.phase === "done";

  const publish = () => {
    if (!confirm("Los amigos verán todos los resultados y podrán descargar sus diplomas. ¿Publicar ahora?")) return;
    run(async () => {
      const revealed = items.map((it, k) => ({ cid: it.cid, pid: it.pid, votes: it.votes, n: k + 1 }));
      await setDoc(doc(db, "config", "ceremony"), { revealed, current: null, total: items.length });
      await setDoc(doc(db, "config", "state"), { phase: "done" }, { merge: true });
      toast("Diplomas publicados 🎉");
    });
  };
  const hide = () => confirm("¿Volver a ocultar los resultados a tus amigos?") && run(async () => {
    await deleteDoc(doc(db, "config", "ceremony"));
    await setDoc(doc(db, "config", "state"), { phase: "ceremony" }, { merge: true });
  });

  return h("div", {},
    h("div", { class: "card" }, h("h3", {}, "Tu presentación"),
      h("p", { class: "mut" }, "Solo tú ves los resultados. Comparte pantalla o proyecta esta página y pasa categoría por categoría. Tus amigos solo ven un mensaje de “sorpresa” hasta que publiques los diplomas."),
      h("button", { class: "btn", onclick: () => present(items) }, "🎬 Iniciar presentación"),
      h("p", { class: "mut sm" }, "Dentro: → o espacio = avanzar · ← = retroceder · Esc = salir. En el celular usa los botones.")),
    h("div", { class: "card" }, h("h3", {}, "Entrega de diplomas"),
      published
        ? [h("p", { class: "ok" }, "✔ Diplomas publicados: tus amigos ya pueden verlos y descargarlos."),
          h("button", { class: "ghost danger", onclick: hide }, "Volver a ocultar")]
        : [h("p", { class: "mut" }, "Cuando termines la presentación, publica los diplomas para que cada quien descargue los suyos."),
          h("button", { class: "btn", onclick: publish }, "📣 Publicar diplomas a los amigos")]));
}

function present(items) {
  const s = st();
  const total = items.length;
  const cat = (id) => D.cats.find((c) => c.id === id);
  const steps = [{ t: "intro" }, ...items.flatMap((_, k) => [{ t: "cat", k }, { t: "win", k }]), { t: "outro" }];
  let i = 0;
  const ov = h("div", { class: "present" });
  const stage = h("div", { class: "pstage" });
  const hint = h("div", { class: "phint" });
  const back = h("button", { class: "ghost", onclick: () => go(-1) }, "◀");
  const fwd = h("button", { class: "btn", onclick: () => go(1) }, "▶");
  const close = h("button", { class: "ghost", onclick: () => exit() }, "✕ Salir");
  ov.append(stage, h("div", { class: "pbar" }, back, fwd, hint, close));
  document.body.append(ov);

  const onKey = (e) => {
    if (e.key === "ArrowRight" || e.key === " ") { e.preventDefault(); go(1); }
    else if (e.key === "ArrowLeft") go(-1);
    else if (e.key === "Escape") exit();
  };
  document.addEventListener("keydown", onKey);
  function exit() { document.removeEventListener("keydown", onKey); ov.remove(); }
  function go(d) { const n = i + d; if (n < 0 || n >= steps.length) return; i = n; draw(); }

  async function draw() {
    const step = steps[i];
    back.disabled = i === 0; fwd.disabled = i === steps.length - 1;
    hint.textContent = `${i + 1} / ${steps.length}`;
    if (step.t === "intro") {
      stage.replaceChildren(h("div", { class: "big" }, "🎭"),
        h("h2", { class: "ptitle" }, `Premios ${s.eventTitle}`.trim()),
        h("p", { class: "mut" }, `${total} categorías · ${D.parts.length} personas · pulsa ▶ para empezar`));
    } else if (step.t === "cat") {
      const c = cat(items[step.k].cid);
      stage.replaceChildren(h("div", { class: "big drum" }, "🥁"),
        h("p", { class: "mut" }, `Categoría ${step.k + 1} de ${total}`),
        h("h2", { class: "pcat" }, c?.name || ""),
        c?.prize ? h("p", { class: "mut" }, `Premio: ${c.prize}`) : null,
        h("p", { class: "mut" }, "Y el diploma es para…"));
    } else if (step.t === "win") {
      const it = items[step.k];
      const c = cat(it.cid);
      const box = h("div", { class: "pdip" });
      stage.replaceChildren(h("div", { class: "big" }, "🏆"),
        h("p", { class: "mut" }, c?.name || ""),
        h("h2", { class: "pwin" }, pname(it.pid)),
        h("p", { class: "mut" }, `${it.votes} voto${it.votes === 1 ? "" : "s"} del jurado`),
        box);
      confetti();
      const my = i;
      const cv = await diplomaCanvas(buildDiplomaOpts({ item: { ...it, n: step.k + 1 }, cats: D.cats, parts: D.parts, state: s, total }));
      if (my === i) { cv.className = "dipcv"; box.append(cv); }
    } else {
      const per = D.parts.map((p) => ({ p, got: items.filter((it) => it.pid === p.id) }));
      stage.replaceChildren(h("div", { class: "big" }, "🎓"),
        h("h2", { class: "ptitle" }, "¡Todos tienen diploma!"),
        h("div", { class: "pgrid" }, per.map(({ p, got }) => h("div", { class: "pcard" },
          h("b", {}, p.name), got.map((it) => h("div", { class: "mut sm" }, cat(it.cid)?.name || ""))))));
    }
  }
  draw();
}
