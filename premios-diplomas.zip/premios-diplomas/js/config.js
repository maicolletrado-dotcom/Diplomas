// =====================================================================
//  CONFIGURACIÓN — pega aquí los datos de TU proyecto de Firebase
//  (Firebase Console → Configuración del proyecto → Tus apps → Web).
//  Estos valores son públicos por diseño: la seguridad está en
//  firestore.rules, no en ocultar esta config.
// =====================================================================
export const firebaseConfig = {
  apiKey: "AIzaSyDwGvGtNfC8M6I1kU_Zjbtzmxd6F4cDW9M",
  authDomain: "diplomas-87bfe.firebaseapp.com",
  projectId: "diplomas-87bfe",
  storageBucket: "diplomas-87bfe.firebasestorage.app",
  messagingSenderId: "676768842040",
  appId: "1:676768842040:web:209ce68560f1d4975a01cd",
};

// Firma que aparece en los diplomas
export const SIGNER_NAME = "Michael Letrado";
export const SIGNER_TITLE = "Presidente del Jurado";
