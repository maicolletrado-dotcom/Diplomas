// Lógica pura (sin DOM ni Firebase): conteo de votos y reparto de diplomas.

export function normalizeText(s) {
  return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "")
    .toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

export function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Cuenta solo votos válidos. Cada votante nomina a cada otra persona en una categoría:
 *  - no puede votarse a sí mismo
 *  - no puede repetir persona (un solo voto por persona)
 *  - no puede repetir categoría (cada categoría una sola vez)
 *  - `votesPerPerson` es un tope opcional (por defecto sin tope: ya lo limitan las reglas anteriores)
 * votes: [{ id: votanteId, picks: [{pid, cid}] }]
 */
export function tally({ parts, cats, votes, votesPerPerson = Infinity }) {
  const pids = new Set(parts.map((p) => p.id));
  const cids = new Set(cats.map((c) => c.id));
  const counts = {};
  for (const c of cats) counts[c.id] = {};
  const voted = {};
  let invalid = 0;
  for (const v of votes) {
    if (!pids.has(v.id)) continue;
    const usedC = new Set();
    const usedP = new Set();
    let ok = 0;
    for (const pk of v.picks || []) {
      const bad = ok >= votesPerPerson || !cids.has(pk.cid) || !pids.has(pk.pid) ||
        pk.pid === v.id || usedC.has(pk.cid) || usedP.has(pk.pid);
      if (bad) { invalid++; continue; }
      usedC.add(pk.cid); usedP.add(pk.pid); ok++;
      counts[pk.cid][pk.pid] = (counts[pk.cid][pk.pid] || 0) + 1;
    }
    voted[v.id] = ok;
  }
  return { counts, voted, invalid };
}

/** Algoritmo húngaro (min coste). a: n×m con n ≤ m. Devuelve columna asignada a cada fila. */
export function hungarian(a) {
  const n = a.length, m = a[0].length, INF = 1e15;
  const u = new Array(n + 1).fill(0), v = new Array(m + 1).fill(0);
  const p = new Array(m + 1).fill(0), way = new Array(m + 1).fill(0);
  for (let i = 1; i <= n; i++) {
    p[0] = i;
    let j0 = 0;
    const minv = new Array(m + 1).fill(INF);
    const used = new Array(m + 1).fill(false);
    do {
      used[j0] = true;
      const i0 = p[j0];
      let delta = INF, j1 = 0;
      for (let j = 1; j <= m; j++) {
        if (used[j]) continue;
        const cur = a[i0 - 1][j - 1] - u[i0] - v[j];
        if (cur < minv[j]) { minv[j] = cur; way[j] = j0; }
        if (minv[j] < delta) { delta = minv[j]; j1 = j; }
      }
      for (let j = 0; j <= m; j++) {
        if (used[j]) { u[p[j]] += delta; v[j] -= delta; } else minv[j] -= delta;
      }
      j0 = j1;
    } while (p[j0] !== 0);
    do { const j1 = way[j0]; p[j0] = p[j1]; j0 = j1; } while (j0);
  }
  const ans = new Array(n).fill(-1);
  for (let j = 1; j <= m; j++) if (p[j]) ans[p[j] - 1] = j - 1;
  return ans;
}

/**
 * Asigna cada categoría a una persona maximizando los votos totales,
 * con tope de `diplomasPerPerson` por persona. Los empates (y las categorías
 * sin votos) se resuelven al azar con `seed`.
 */
export function assign({ parts, cats, counts, diplomasPerPerson, seed = 1 }) {
  const slots = parts.flatMap((p) => Array(diplomasPerPerson).fill(p.id));
  if (cats.length > slots.length) {
    throw new Error(`Hay ${cats.length} categorías pero solo ${slots.length} cupos de diploma.`);
  }
  if (!cats.length) return [];
  const rnd = mulberry32(seed);
  const cost = cats.map((c) => slots.map((pid) => -(counts[c.id]?.[pid] || 0) * 1000 + rnd()));
  const ans = hungarian(cost);
  return cats.map((c, i) => {
    const pid = slots[ans[i]];
    const row = counts[c.id] || {};
    const topVotes = Math.max(0, ...Object.values(row));
    const topPids = topVotes > 0 ? Object.keys(row).filter((k) => row[k] === topVotes) : [];
    return { cid: c.id, pid, votes: row[pid] || 0, topVotes, topPids };
  });
}
