import { buildDiplomaOpts, diplomaCanvas, canvasBlob, shareOrDownload } from "./diploma.js";

export const $ = (s, r = document) => r.querySelector(s);

/** Mini helper para crear elementos: h('div', {class:'x', onclick}, hijos...) */
export function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "value" || k === "checked" || k === "disabled") e[k] = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    e.append(kid.nodeType ? kid : document.createTextNode(kid));
  }
  return e;
}

export function slug(s) {
  return String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
    .replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "x";
}
const initials = (n) => n.split(/\s+/).slice(0, 2).map((w) => w[0] || "").join("").toUpperCase();
const hue = (n) => { let x = 0; for (const c of n) x = (x * 31 + c.charCodeAt(0)) % 360; return x; };
export const avatar = (name) =>
  h("span", { class: "av", style: `background:hsl(${hue(name)} 55% 42%)` }, initials(name));

export function toast(msg, bad = false) {
  const t = h("div", { class: `toast${bad ? " bad" : ""}` }, msg);
  document.body.append(t);
  setTimeout(() => t.classList.add("out"), 2600);
  setTimeout(() => t.remove(), 3100);
}

export function confetti(ms = 3800) {
  const c = h("canvas", { class: "confetti" });
  document.body.append(c);
  const dpr = window.devicePixelRatio || 1;
  c.width = innerWidth * dpr; c.height = innerHeight * dpr;
  const ctx = c.getContext("2d");
  const colors = ["#f5c451", "#ff6b9d", "#58d68d", "#6bc5ff", "#c77dff", "#fff"];
  const ps = Array.from({ length: 170 }, () => ({
    x: Math.random() * c.width, y: -Math.random() * c.height * 0.5,
    vx: (Math.random() - 0.5) * 6 * dpr, vy: (2 + Math.random() * 5) * dpr,
    s: (6 + Math.random() * 8) * dpr, r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4,
    col: colors[(Math.random() * colors.length) | 0],
  }));
  const t0 = performance.now();
  (function frame(t) {
    ctx.clearRect(0, 0, c.width, c.height);
    for (const p of ps) {
      p.x += p.vx; p.y += p.vy; p.r += p.vr; p.vy += 0.05 * dpr;
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r);
      ctx.fillStyle = p.col; ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); ctx.restore();
    }
    if (t - t0 < ms) requestAnimationFrame(frame); else c.remove();
  })(t0);
}

/** Ventana con el diploma renderizado + botón de descargar/compartir. */
export async function openDiploma(o) {
  const dlg = h("dialog", { class: "dip" }, h("p", { class: "mut" }, "Preparando diploma…"));
  document.body.append(dlg);
  dlg.addEventListener("close", () => dlg.remove());
  dlg.showModal();
  const cv = await diplomaCanvas(o);
  cv.className = "dipcv";
  dlg.replaceChildren(
    cv,
    h("div", { class: "row" },
      h("button", {
        class: "btn",
        onclick: async () => shareOrDownload(await canvasBlob(cv), `diploma-${slug(o.name)}-${slug(o.category)}.png`),
      }, "⬇ Descargar / compartir"),
      h("button", { class: "ghost", onclick: () => dlg.close() }, "Cerrar")),
  );
}

/**
 * Vista de la ceremonia (la usan los amigos y el admin).
 * cer = doc config/ceremony: { revealed:[{cid,pid,votes,n}], current:{index,cid,stage,pid?,votes?}|null, total }
 */
export function ceremonyView({ cer, cats, parts, state, meId, done = false }) {
  const P = Object.fromEntries(parts.map((p) => [p.id, p]));
  const C = Object.fromEntries(cats.map((c) => [c.id, c]));
  const total = cer?.total || cats.length;
  const revealed = cer?.revealed || [];
  const cur = cer?.current;
  const open = (it) => openDiploma(buildDiplomaOpts({ item: it, cats, parts, state, total }));

  const stage = h("div", { class: "stage" });
  if (done) {
    stage.append(h("div", { class: "big" }, "🎓"), h("h2", {}, "¡Todos tienen diploma!"),
      h("p", { class: "mut" }, "Descarga los tuyos y compártelos en el grupo."));
  } else if (!cur) {
    stage.append(h("div", { class: "big" }, "🎭"), h("h2", {}, "La ceremonia está por comenzar"),
      h("p", { class: "mut" }, "Mantén esta pantalla abierta…"));
  } else if (cur.stage === "category") {
    stage.append(h("div", { class: "big drum" }, "🥁"),
      h("p", { class: "mut" }, `Categoría ${cur.index + 1} de ${total}`),
      h("h2", { class: "cat" }, C[cur.cid]?.name || ""),
      C[cur.cid]?.prize ? h("p", { class: "mut" }, `Premio: ${C[cur.cid].prize}`) : null,
      h("p", { class: "mut" }, "Y el diploma es para…"));
  } else {
    stage.append(h("div", { class: "big" }, "🏆"),
      h("p", { class: "mut" }, C[cur.cid]?.name || ""),
      h("h2", { class: "winner" }, P[cur.pid]?.name || "?"),
      h("p", { class: "mut" }, `${cur.votes || 0} voto${cur.votes === 1 ? "" : "s"} del jurado`));
  }

  const mine = revealed.filter((r) => r.pid === meId);
  const row = (r) => h("div", { class: "rrow" },
    avatar(P[r.pid]?.name || "?"),
    h("div", { class: "grow" }, h("b", {}, P[r.pid]?.name || "?"), h("div", { class: "mut sm" }, C[r.cid]?.name || "")),
    h("button", { class: "ghost sm", onclick: () => open(r) }, "Ver diploma"));

  return h("div", {},
    stage,
    mine.length ? h("section", { class: "card" }, h("h3", {}, "🎖 Tus diplomas"), mine.map(row)) : null,
    revealed.length
      ? h("section", { class: "card" }, h("h3", {}, `Ya entregados (${revealed.length}/${total})`),
        [...revealed].reverse().map(row))
      : null,
  );
}
