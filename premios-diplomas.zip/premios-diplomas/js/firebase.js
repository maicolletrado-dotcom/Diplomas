import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getFirestore, doc, collection, getDoc, setDoc, deleteDoc, onSnapshot, writeBatch, serverTimestamp,
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import {
  getAuth, signInAnonymously, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signOut,
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { firebaseConfig } from "./config.js";

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export {
  doc, collection, getDoc, setDoc, deleteDoc, onSnapshot, writeBatch, serverTimestamp,
  onAuthStateChanged, signOut,
};

export const googleSignIn = () => signInWithPopup(auth, new GoogleAuthProvider());

/** Sesión anónima para los amigos (la identidad real la da la clave). */
export function ensureAnon() {
  return new Promise((resolve, reject) => {
    const off = onAuthStateChanged(auth, async (u) => {
      off();
      if (u) return resolve(u);
      try { resolve((await signInAnonymously(auth)).user); } catch (e) { reject(e); }
    });
  });
}

/** Prueba de clave: el servidor (reglas) la compara con secrets/{pid}.hash */
export async function proofFor(pid, clave) {
  const data = new TextEncoder().encode(`${pid}:${String(clave)}:premios`);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
